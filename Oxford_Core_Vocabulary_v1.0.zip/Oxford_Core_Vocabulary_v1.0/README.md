# Oxford Core Vocabulary v1.0

6,100レコードの固定Corpusを検索・演習し、回答履歴と操作履歴を外部SQLiteへ保存する個人用Webアプリです。GoがHTTP、CSV読込、問題生成・採点、履歴を担当し、`web/index.html`一枚にCSSとJavaScriptを内包したSPAを配信します。

## 1. 起動

### ソースから起動する（macOS / Linux）

必要なものは **Go 1.24以降とCコンパイラー**です。この実装のSQLiteドライバーはCGOを使用します。SQLite本体のソースはドライバーに同梱されるため、SQLiteサーバー、sqlite3コマンド、システムのSQLite開発用ヘッダーの別途導入は不要です。Node.js・npm・外部CDNも実行時には不要です。Go依存ソースは`vendor/`に同梱しています。

ZIPを展開し、`go.mod`のあるディレクトリーへ移動して実行します。

```sh
CGO_ENABLED=1 go run -buildvcs=false -mod=vendor -tags sqlite_omit_load_extension .
```

ブラウザーで **[http://127.0.0.1:8080/](http://127.0.0.1:8080/)** を開きます。初回起動時に`data/learning.db`と7テーブルを自動作成します。終了はターミナルの`Ctrl+C`です。

macOSではGoに加え、AppleのCommand Line Tools（`xcode-select --install`）に含まれるCコンパイラーを利用できます。LinuxではGCC等が必要です。Cコンパイラーはビルド時に使います。

### 同梱Linux x86-64バイナリで起動する

```sh
chmod +x bin/oxford-core-linux-amd64
./bin/oxford-core-linux-amd64
```

同梱バイナリは**静的リンク済みのLinux x86-64用**です。実行先にGo、Cコンパイラー、SQLite共有ライブラリーは不要です。macOS用バイナリではありません。macOSでは上記のソース起動、または次のコマンドでそのMac用にビルドします。

```sh
CGO_ENABLED=1 go build -buildvcs=false -mod=vendor -trimpath -tags sqlite_omit_load_extension -o bin/oxford-core .
./bin/oxford-core
```

### 配置先やポートを指定する

```sh
./bin/oxford-core \
  -addr 127.0.0.1:8080 \
  -csv ./data/all_with_ID.csv \
  -db ./data/learning.db
```

相対パスは起動時の作業ディレクトリーを基準にします。別の場所から起動する場合はCSV・DBを絶対パスで指定してください。起動中はCSVをメモリーへ読み込み、学習内容の正本は引き続き外部CSVにあります。

## 2. 同梱物

| ファイル／ディレクトリー | 用途 |
|---|---|
| `*.go`、`go.mod`、`go.sum` | Goアプリとテスト、固定した依存関係 |
| `schema.sql` | 7テーブルの初期DDL |
| `web/index.html` | 本番用の唯一のHTML。CSS・JavaScriptを内包 |
| `data/all_with_ID.csv` | 変更していないCorpus正本 |
| `vendor/` | SQLiteドライバー、Unicode正規化の依存ソースとライセンス |
| `bin/oxford-core-linux-amd64` | 実行検証したLinux x86-64バイナリ |
| `tests/verify_api.py` | 一時DBを使う独立したAPI・SQLite検証 |
| `tests/frontend_control_flow_regression.cjs` | 実際のFrontend関数を使った非同期処理の回帰検証 |
| `docs/API_CONTRACT.md` | HTTP APIとデータ形式 |
| `docs/SPECIFICATION_v1.0.md` | 提供された仕様書の保存コピー |
| `docs/Oxford_Core_UI_Selections.json` | 全10画面PC=A／Mobile=Aの選定記録 |
| `VERIFICATION.md` | §22の18項目の実行結果と検証範囲 |
| `test-results/` | 実際に実行した検証の出力 |

参考モック20枚と旧Reading HTMLは、本番ページとして同梱していません。10 Viewを単一SPAに統合しています。

`web/index.html`と`schema.sql`はビルド時にGoバイナリへ埋め込まれます。HTMLを編集した場合は再ビルドしてください。バイナリ実行時に必要な永続ファイルは外部CSVとDBです。

## 3. 使い方

### Dictionary

Heroの検索欄でEnterを押すと、入力を引き継いでDictionaryへ進みます。自由入力はWORD・POS・LEVEL・SECTION・JP・EXAMPLE全体に対する部分一致です。NFKC正規化・大小文字無視で、空白区切りの語はすべて一致する必要があります。例えば複数語が別々のフィールドに一致しても検索対象になります。

POS・LEVEL・SECTIONは複数選択でき、同じ属性内はOR、属性の間はANDです。未選択は無制限です。A〜ZはWORDの頭文字で絞り込みます。CorpusにX始まりの登録はなく、Xの検索結果は0件です。LEVELの3000／5000はCorpusの所属ラベルで、CEFRではありません。

語義の表示、一括表示、押している間の一時表示を使えます。JPは単語の短い日本語ラベルで、英文全体の対訳ではありません。

### Quiz

Quiz → 形式選択 → NEW／Review → 条件・件数・方向／提示形式 → Startの順です。NEWは新しい問題定義を作る操作で、初見単語限定ではありません。

| 形式 | 提示と回答 | 保存する評価 |
|---|---|---|
| Word Recall | EN→JP／JP→ENの四択 | 選択Corpus ID、客観正誤、Confidence |
| Cloze Test | EXAMPLE中の一か所を空欄にし文字列で回答 | 入力原文、客観正誤、Confidence |
| Reading Review | WORD＋英語例文／JPラベル＋英語例文 | `recalled`、Confidence。客観正誤はNULL |
| Sentence Generation | Coming soon... | Session・Attemptは作成しない |

回答は確定操作後に保存します。Confidenceは任意で、未設定はNULL、明示した0は0です。正解を表示する前の値を保存します。Unknownは意識的な「分からない」という回答です。前後移動や選択しただけの操作は回答に数えません。

Reading Reviewでは右スワイプ／「できた」、左スワイプ／「できなかった」が同じ自己評価選択になります。Confidenceを必要に応じて設定し、確定します。中断したスワイプではAttemptを作りません。

Word Recallの回答後は4候補すべてのWORD・POS・JPを確認できます。ABXYは表示上の位置で、履歴には選んだCorpus IDを保存します。候補IDは問題定義に固定し、表示順はGoがSession・問題位置から再構成します。表示順そのものはDBに保存しません。

ClozeはWORDの原形ではなく実際に空欄にした例文中の文字列を正答とします。開始位置と長さはUnicodeコードポイント（Goのrune）の0基準です。採点時はNFKC正規化・大小文字無視・前後空白除去・連続空白の統一を行い、類義語への置き換えは正解にしません。入力した原文はそのままAttemptへ残します。**同梱のCorpusは6,100件すべてに有効な空欄位置を特定でき、除外は0件**です。安全に位置を特定できない行がある場合の処理も実装し、候補から除外して除外件数を表示します。

### キーボードとゲームパッド

| 入力 | 動作 |
|---|---|
| Word Recallの`1`〜`4`／`A`・`B`・`X`・`Y` | 表示中の4候補から選択 |
| `Enter` | 回答確定。保存済みなら次の問題へ。Cloze入力欄内でも確定可能 |
| `U` | Unknownを確定 |
| 左右矢印 | Quizの前後移動。Reading Review中は左＝できなかった、右＝できたの選択 |
| `Space`を押している間 | Dictionary／対応するReadingカードの日本語ラベルを一時表示 |
| PCゲームパッドのLB／RB | 前後移動 |
| ゲームパッドのABXY | Word Recallの4候補を選択 |
| ゲームパッドのAを押している間 | Dictionary／対応するReadingカードの日本語ラベルを一時表示。四択中のAは回答選択用 |
| Reading中のゲームパッドX／Y、十字キー左／右 | できなかった／できたを選択 |
| LT／RT、縦スティック | Confidenceを減少／増加 |
| 横スティック | 回答候補へフォーカス移動 |
| R3／Start | 回答確定／Unknown |

入力欄で文字を入力中は、その入力を優先します。ゲームパッドはブラウザーの標準マッピングを前提とし、PC幅で有効になります。実機での検証範囲は`VERIFICATION.md`を参照してください。

### ReviewとResume

Reviewは過去に一度でも条件を満たしたAttemptから**既存の問題定義を選び、新しいSession**を作ります。後で正解した問題も、過去に間違えた履歴が残っていればIncorrect条件で選べます。結果・Confidence・日時は同じAttemptに対して評価します。

Incorrectは通常回答の客観誤答、Unknownは明示的なUnknown、Readingの「できなかった」は自己評価です。これらを別条件として扱います。

ResumeはReview内の一覧から**同じSession**に戻ります。Session ID、問題順、現在位置、確定済み回答を復元します。全問題位置で1件以上の回答またはUnknownを確定するとCompletedになります。再回答は既存履歴を上書きせず追記します。

### Collection

DictionaryのVocabulary CollectionはCorpus ID、Quizから保存するQuestion CollectionはQuestion Spec IDを保持します。同じIDを同じCollectionへ追加すると警告し、明示的に続行した場合だけ重複登録します。登録行ごとに削除できます。重複した項目は練習時の繰り返し回数にも反映します。

### Data

回答履歴では問題、回答日時、形式・方向／提示形式、選択／入力、正誤、Unknown、自己評価、Confidenceを参照できます。操作履歴では発生日時、画面、イベント、対象、関連Session／Attemptを確認できます。

正答率は客観的な採点がある問題だけを分母にします。Reading Reviewの自己評価を正解率へ混ぜません。画面の入退場から求めた利用時間は概算として表示し、終了記録のない区間は不明として扱います。

## 4. 永続化の設計

SQLiteのアプリテーブルは`question_specs`、`sessions`、`session_questions`、`attempt_logs`、`action_logs`、`collections`、`collection_items`の7つです。Corpus本文・正答文を教材の複製として保存せず、Question SpecのJSONも保存しません。Corpus IDは元の整数のまま、生成するSession・Question・Attempt・Action・Activity・Collection・登録項目のIDはAPI／画面で8桁数字として扱います。

- `question_specs.parameters`は仕様書§5の整数列です。
- `sessions.filter_spec`は§9.6のversion 1・タグと値数付き整数列です。自由入力の元の大小文字・空白をUnicodeコードポイントとして保持し、A〜Zはタグ7、件数は必須タグ12へ保存します。
- `attempt_logs`は確定回答を追記します。関連する回答Actionを同じトランザクションで保存し、`attempt_id`で結び付けます。
- `action_logs`は指定された9カラムです。操作発生時刻`occurred_at`と、送信時刻`sent_at`／受信時刻を混同しません。送信時刻はAPIの封筒情報で、Actionの追加カラムにはしません。
- 一般操作のActionはFrontendで蓄積し、画面遷移、回答確定、30秒間隔の定期送信、非表示化でまとめて送ります。ログ送信待ちで画面の開閉や閲覧を止めません。
- 回答保存が失敗した場合は保存成功として扱いません。完全オフライン同期・業務監査水準の無欠落ログは対象外です。

CSVの固定SHA-256：

```text
9c871e809b082836339c665aa611476602301f3e6425eca0ded34185d8093f72
```

通常起動ではヘッダー、行数、ID、語彙と品詞の一意性に加え、このSHA-256との一致を確認します。CSVが変更されていた場合は起動を停止します。過去の問題定義が参照する語句や空欄位置を変えないための固定Corpus運用です。CSVだけを確認する場合は、DBを開かずに次を実行できます。

```sh
./bin/oxford-core-linux-amd64 -check-corpus
```

## 5. Tailscaleから使う

Goアプリを`127.0.0.1:8080`で起動し、別のターミナルで実行します。

```sh
tailscale serve --bg 8080
```

Tailscaleが返すHTTPS URLを同じTailnetのPC・スマートフォンで開きます。両端末は同じGoプロセスとDBへ接続します。個別端末にDBを複製して同期する方式ではありません。認証・接続範囲は利用するTailnet設定に従います。

この環境では利用者のTailnetへ接続する実機試験はしていません。手順は[Tailscale公式Serveドキュメント](https://tailscale.com/docs/reference/tailscale-cli/serve)を確認しています。

PWA用manifest、アイコン、Service WorkerはGoがURLから配信します。ホーム画面へのインストールと、完全オフラインでの回答・同期は別です。後者は実装対象外です。

## 6. 検証を再実行する

```sh
CGO_ENABLED=1 go test -buildvcs=false -mod=vendor ./...
CGO_ENABLED=1 go build -buildvcs=false -mod=vendor -trimpath -tags sqlite_omit_load_extension -o bin/oxford-core .
python3 tests/verify_api.py \
  --binary ./bin/oxford-core \
  --corpus ./data/all_with_ID.csv \
  --output ./test-results/api-verification.json
```

Python検証には標準ライブラリーだけを使います。独立した一時DBを作成し、通常の`data/learning.db`へ試験データを書き込みません。画面や実機の試験をAPI試験の成功で代用しません。実際に行った環境・方法・結果と未検証範囲は`VERIFICATION.md`に記載しています。

任意の開発用検証として、Node.jsがあれば次も実行できます。アプリの起動にはNode.jsは不要です。

```sh
node tests/frontend_control_flow_regression.cjs
```

この回帰検証は実際のFrontend関数と制御したPromise・DOM代替を使います。実ブラウザーやタッチ端末を自動操作するテストではありません。

## 7. 保守と実装範囲

バックアップはアプリを正常終了してから外部DBとCSVをコピーしてください。稼働中にファイルコピーする場合はWALとの整合が必要になるため、停止中のコピーを基本にします。配布ZIPには試験で生成した学習DBを含めません。

依存関係は`github.com/mattn/go-sqlite3 v1.14.32`と`golang.org/x/text v0.28.0`です。依存ライセンスは`vendor/`内に保持しています。

Sentence Generation本体、GPT採点、SRS・忘却曲線、複数Corpus、完全オフライン同期、厳密な複数端末競合解決は対象外です。未確定入力の端末間同期は行いません。学習履歴は外部DBに永続化し、同一サーバーに接続する端末からResumeできます。
